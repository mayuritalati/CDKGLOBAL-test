This is spring boot project .I have used h2 database and developed the rest api to get the discounted bill amount. This REST API takes two query param customerType and totalAmount

All the bootstrap data which is require to calculate discount are stored in h2 database.
This Project contains schema.sql and data.sql file which contains DDL and DML.
On server startup it will create tables and insert the static data into database.
Also, I am calculating max discount till previous row and storing in max_disc_till_last_range column. So that when I am calculating discount on totalAmount,  needs to calculate discount only for the current row and previous range discount is available in max_disc_till_last_range with current row data. so total discount will be current discount + max_disc_till_last_range
If discount range modification happens in database. There will be a database trigger which will trigger on update of discount range and will calculate the max_disc_till_last_range again.

to access the application plz access url http://localhost:9090/rest/0.1/billing?customerType=regular&totalAmount=15000 from the browser.
possible value of customerType is regular, premium
total amount can be any value between 1 to 2147483647.

I have added integration test cases to test this application.
