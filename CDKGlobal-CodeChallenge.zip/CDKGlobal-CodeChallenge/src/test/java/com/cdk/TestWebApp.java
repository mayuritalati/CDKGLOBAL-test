package com.cdk;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

public class TestWebApp extends CdkGlobalCodeChallengeApplicationTests {

	@Autowired
	private WebApplicationContext webApplicationContext;

	private MockMvc mockMvc;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}
	
	

	
	@Test
	public void testBillDiscount1() throws Exception {
		
		mockMvc.perform(get("/rest/0.1/billing?customerType=regular&totalAmount=15000")).andExpect(status().isOk())
				.andExpect(jsonPath("$.totalAmount").value(15000))
				.andExpect(jsonPath("$.customerType").value("regular"))
				.andExpect(jsonPath("$.amountToBePaid").value(13500.0));

	}
	
	@Test
	public void testBillDiscount2() throws Exception {
		//mockMvc.perform(get("/rest/0.1/billing/default-discount")).andExpect(status().isOk());
		mockMvc.perform(get("/rest/0.1/billing?customerType=regular&totalAmount=5000")).andExpect(status().isOk())
				.andExpect(jsonPath("$.totalAmount").value(5000))
				.andExpect(jsonPath("$.customerType").value("regular"))
				.andExpect(jsonPath("$.amountToBePaid").value(5000.0));

	}
	
	@Test
	public void testBillDiscount3() throws Exception {
		//mockMvc.perform(get("/rest/0.1/billing/default-discount")).andExpect(status().isOk());
		mockMvc.perform(get("/rest/0.1/billing?customerType=regular&totalAmount=10000")).andExpect(status().isOk())
				.andExpect(jsonPath("$.totalAmount").value(10000))
				.andExpect(jsonPath("$.customerType").value("regular"))
				.andExpect(jsonPath("$.amountToBePaid").value(9500.0));

	}
	
	@Test
	public void testBillDiscount5() throws Exception {
		//mockMvc.perform(get("/rest/0.1/billing/default-discount")).andExpect(status().isOk());
		mockMvc.perform(get("/rest/0.1/billing?customerType=premium&totalAmount=4000")).andExpect(status().isOk())
				.andExpect(jsonPath("$.totalAmount").value(4000))
				.andExpect(jsonPath("$.customerType").value("premium"))
				.andExpect(jsonPath("$.amountToBePaid").value(3600.0));

	}
	
	@Test
	public void testBillDiscount6() throws Exception {
		//mockMvc.perform(get("/rest/0.1/billing/default-discount")).andExpect(status().isOk());
		mockMvc.perform(get("/rest/0.1/billing?customerType=premium&totalAmount=8000")).andExpect(status().isOk())
				.andExpect(jsonPath("$.totalAmount").value(8000))
				.andExpect(jsonPath("$.customerType").value("premium"))
				.andExpect(jsonPath("$.amountToBePaid").value(7000.0));

	}
	
	@Test
	public void testBillDiscount7() throws Exception {
		//mockMvc.perform(get("/rest/0.1/billing/default-discount")).andExpect(status().isOk());
		mockMvc.perform(get("/rest/0.1/billing?customerType=premium&totalAmount=12000")).andExpect(status().isOk())
				.andExpect(jsonPath("$.totalAmount").value(12000))
				.andExpect(jsonPath("$.customerType").value("premium"))
				.andExpect(jsonPath("$.amountToBePaid").value(10200.0));

	}
	
	@Test
	public void testBillDiscount4() throws Exception {
		//mockMvc.perform(get("/rest/0.1/billing/default-discount")).andExpect(status().isOk());
		mockMvc.perform(get("/rest/0.1/billing?customerType=premium&totalAmount=20000")).andExpect(status().isOk())
				.andExpect(jsonPath("$.totalAmount").value(20000))
				.andExpect(jsonPath("$.customerType").value("premium"))
				.andExpect(jsonPath("$.amountToBePaid").value(15800.0));

	}

}