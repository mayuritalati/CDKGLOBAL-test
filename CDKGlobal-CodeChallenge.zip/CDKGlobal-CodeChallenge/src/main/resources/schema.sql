
DROP TABLE IF EXISTS cust_discount_details;
DROP TABLE IF EXISTS customer_details;


CREATE TABLE  customer_details (
  cust_type_id int(11) NOT NULL AUTO_INCREMENT,
  cust_type varchar(255) DEFAULT NULL,
  PRIMARY KEY (cust_type_id)
);


CREATE TABLE  cust_discount_details (
  disc_id int(11) NOT NULL AUTO_INCREMENT,
  discount int(11) DEFAULT NULL,
  max_disc_till_last_range decimal(19,2) DEFAULT NULL,
  max_range int(11) DEFAULT NULL,
  min_range int(11) DEFAULT NULL,
  cust_type_id int(11) DEFAULT NULL,
  PRIMARY KEY (disc_id)
);