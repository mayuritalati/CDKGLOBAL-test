INSERT INTO customer_details(cust_type_id,cust_type) VALUES
  (1,'regular'),
  (2,'premium');
INSERT INTO cust_discount_details (disc_id,discount,max_disc_till_last_range,max_range,min_range,cust_type_id) VALUES
  (1,0,0.00,5000,0,1),
  (2,10,0.00,10000,5000,1),
  (3,20,500,2147483647,10000,1),
  (4,10,0.00,4000,0,2),
  (5,15,400.00,8000,4000,2),
  (6,20,1000.00,12000,8000,2),
  (7,30,1800.00,2147483647,12000,2)
  ;