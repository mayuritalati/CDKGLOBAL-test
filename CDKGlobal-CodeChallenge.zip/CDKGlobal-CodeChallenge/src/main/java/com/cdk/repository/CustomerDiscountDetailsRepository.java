package com.cdk.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cdk.entity.CustomerDiscountDetailsEntity;
@Repository
public interface CustomerDiscountDetailsRepository extends CrudRepository<CustomerDiscountDetailsEntity, Integer>{

	/**
	 * To get the discount range in which total bill amount lay
	 * @param customerType
	 * @param totalAmount
	 * @return List<CustomerDiscountDetailsEntity>
	 */
	@Query(value = "SELECT e from CustomerDiscountDetailsEntity e WHERE customerType.customerType = :customerType AND e.minRange <=: totalAmount and e.maxRange >= :totalAmount order by e.minRange")
	public List<CustomerDiscountDetailsEntity> findByCustTypeAndRange(@Param(value = "customerType") String customerType, @Param(value = "totalAmount") Integer totalAmount);
	
}
