package com.cdk.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "cust_discount_details")

public class CustomerDiscountDetailsEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // auto increment
	@Column(name = "disc_id")
	private Integer discountId;

	@Column(name = "min_range")
	private Integer minRange;

	@Column(name = "max_range")
	private Integer maxRange;

	@Column(name = "discount")
	private Integer discount;

	@Column(name = "max_disc_till_last_range")
	private BigDecimal maxDiscountTillLastRange;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="cust_type_id", referencedColumnName = "cust_type_id")
	private CustomerTypeEntity customerType;
	
	
	public Integer getDiscountId() {
		return discountId;
	}

	public void setDiscountId(Integer discountId) {
		this.discountId = discountId;
	}

	public Integer getStartRange() {
		return minRange;
	}

	public void setStartRange(Integer startRange) {
		this.minRange = startRange;
	}

	public Integer getMaxRange() {
		return maxRange;
	}

	public void setMaxRange(Integer maxRange) {
		this.maxRange = maxRange;
	}

	public Integer getDiscount() {
		return discount;
	}

	public void setDiscount(Integer discount) {
		this.discount = discount;
	}

	public BigDecimal getMaxDiscountTillLastRange() {
		return maxDiscountTillLastRange;
	}

	public void setMaxDiscountTillLastRange(BigDecimal maxDiscountTillLastRange) {
		this.maxDiscountTillLastRange = maxDiscountTillLastRange;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((customerType == null) ? 0 : customerType.hashCode());
		result = prime * result + ((discount == null) ? 0 : discount.hashCode());
		result = prime * result + ((discountId == null) ? 0 : discountId.hashCode());
		result = prime * result + ((maxDiscountTillLastRange == null) ? 0 : maxDiscountTillLastRange.hashCode());
		result = prime * result + ((maxRange == null) ? 0 : maxRange.hashCode());
		result = prime * result + ((minRange == null) ? 0 : minRange.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerDiscountDetailsEntity other = (CustomerDiscountDetailsEntity) obj;
		if (customerType == null) {
			if (other.customerType != null)
				return false;
		} else if (!customerType.equals(other.customerType))
			return false;
		if (discount == null) {
			if (other.discount != null)
				return false;
		} else if (!discount.equals(other.discount))
			return false;
		if (discountId == null) {
			if (other.discountId != null)
				return false;
		} else if (!discountId.equals(other.discountId))
			return false;
		if (maxDiscountTillLastRange == null) {
			if (other.maxDiscountTillLastRange != null)
				return false;
		} else if (!maxDiscountTillLastRange.equals(other.maxDiscountTillLastRange))
			return false;
		if (maxRange == null) {
			if (other.maxRange != null)
				return false;
		} else if (!maxRange.equals(other.maxRange))
			return false;
		if (minRange == null) {
			if (other.minRange != null)
				return false;
		} else if (!minRange.equals(other.minRange))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CustomerDiscountDetailsEntity [discountId=" + discountId + ", startRange=" + minRange + ", maxRange="
				+ maxRange + ", discount=" + discount + ", maxDiscountTillLastRange=" + maxDiscountTillLastRange
				+ ", customerType=" + customerType + "]";
	}
	
}
