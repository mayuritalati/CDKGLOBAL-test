package com.cdk.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "customer_details")
public class CustomerTypeEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // auto increment
	@Column(name = "cust_type_id")
	private Integer custTypeId;

	@Column(name = "cust_type")
	private String customerType;

	@OneToMany(targetEntity=CustomerDiscountDetailsEntity.class, mappedBy="customerType",cascade=CascadeType.ALL, fetch = FetchType.EAGER)    
	private List<CustomerDiscountDetailsEntity> discountRanges;


	public Integer getCustTypeId() {
		return custTypeId;
	}

	public void setCustTypeId(Integer custTypeId) {
		this.custTypeId = custTypeId;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public List<CustomerDiscountDetailsEntity> getDiscountRanges() {
		return discountRanges;
	}

	public void setDiscountRanges(List<CustomerDiscountDetailsEntity> discountRanges) {
		this.discountRanges = discountRanges;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((custTypeId == null) ? 0 : custTypeId.hashCode());
		result = prime * result + ((customerType == null) ? 0 : customerType.hashCode());
		result = prime * result + ((discountRanges == null) ? 0 : discountRanges.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerTypeEntity other = (CustomerTypeEntity) obj;
		if (custTypeId == null) {
			if (other.custTypeId != null)
				return false;
		} else if (!custTypeId.equals(other.custTypeId))
			return false;
		if (customerType == null) {
			if (other.customerType != null)
				return false;
		} else if (!customerType.equals(other.customerType))
			return false;
		if (discountRanges == null) {
			if (other.discountRanges != null)
				return false;
		} else if (!discountRanges.equals(other.discountRanges))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CustomerTypeEntity [custTypeId=" + custTypeId + ", customerType=" + customerType + ", discountRanges="
				+ discountRanges + "]";
	}

	
}
