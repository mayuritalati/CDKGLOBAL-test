package com.cdk.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class CustomerBillDetails implements Serializable{

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private BigDecimal totalAmount;
	private String CustomerType;
	private BigDecimal amountToBePaid;
	private String error;

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getCustomerType() {
		return CustomerType;
	}

	public void setCustomerType(String customerType) {
		CustomerType = customerType;
	}

	public BigDecimal getAmountToBePaid() {
		return amountToBePaid.setScale(1, RoundingMode.CEILING);
	}

	public void setAmountToBePaid(BigDecimal amountToBePaid) {
		this.amountToBePaid = amountToBePaid;
	}
	

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	@Override
	public String toString() {
		return "CustomerBillDetails [totalAmount=" + totalAmount + ", CustomerType=" + CustomerType
				+ ", amountToBePaid=" + amountToBePaid + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((CustomerType == null) ? 0 : CustomerType.hashCode());
		result = prime * result + ((amountToBePaid == null) ? 0 : amountToBePaid.hashCode());
		result = prime * result + ((totalAmount == null) ? 0 : totalAmount.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerBillDetails other = (CustomerBillDetails) obj;
		if (CustomerType == null) {
			if (other.CustomerType != null)
				return false;
		} else if (!CustomerType.equals(other.CustomerType))
			return false;
		if (amountToBePaid == null) {
			if (other.amountToBePaid != null)
				return false;
		} else if (!amountToBePaid.equals(other.amountToBePaid))
			return false;
		if (totalAmount == null) {
			if (other.totalAmount != null)
				return false;
		} else if (!totalAmount.equals(other.totalAmount))
			return false;
		return true;
	}
	
	
	

}
