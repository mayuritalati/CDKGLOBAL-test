package com.cdk.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdk.entity.CustomerDiscountDetailsEntity;
import com.cdk.model.CustomerBillDetails;
import com.cdk.repository.CustomerDiscountDetailsRepository;

@Service
public class CustomerBillingService {
	
	@Autowired
	CustomerDiscountDetailsRepository customerDiscountDetailsRepository;
	
	/**
	 * To calculate the bill amount after discount which will be paid by customer
	 * @param customerBillDetails
	 * @return
	 */
	public CustomerBillDetails calculateDiscount(CustomerBillDetails customerBillDetails){
		List<CustomerDiscountDetailsEntity> customerDiscountDetailsList = customerDiscountDetailsRepository.findByCustTypeAndRange(customerBillDetails.getCustomerType(), customerBillDetails.getTotalAmount().intValue());
		if(customerDiscountDetailsList != null && customerDiscountDetailsList.size() > 0){
			CustomerDiscountDetailsEntity customerDiscountDetailsEntity = customerDiscountDetailsList.get(0);
			BigDecimal totalAmount = customerBillDetails.getTotalAmount();
			BigDecimal discountTillPrev = customerDiscountDetailsEntity.getMaxDiscountTillLastRange();
			BigDecimal discount = totalAmount.subtract(new BigDecimal(customerDiscountDetailsEntity.getStartRange())).multiply(new BigDecimal(customerDiscountDetailsEntity.getDiscount())).multiply(new BigDecimal(.01));
			BigDecimal amountToBePaid = totalAmount.subtract(discount.add(discountTillPrev));
			customerBillDetails.setAmountToBePaid(amountToBePaid);
		}
		return customerBillDetails;
		
	}

}


