package com.cdk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(value = "com.cdk")
public class CdkGlobalCodeChallengeApplication {
	static ConfigurableApplicationContext context;

	public static void main(String[] args) {
		context = SpringApplication.run(CdkGlobalCodeChallengeApplication.class, args);

	}
}
