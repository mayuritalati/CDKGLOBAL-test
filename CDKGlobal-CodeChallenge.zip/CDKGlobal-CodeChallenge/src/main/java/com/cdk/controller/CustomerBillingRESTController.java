package com.cdk.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cdk.model.CustomerBillDetails;
import com.cdk.service.CustomerBillingService;

@RestController
@RequestMapping("rest/0.1/billing")
public class CustomerBillingRESTController {
	
	@Autowired
	CustomerBillingService customerBillingService;
	
	@GetMapping
	public CustomerBillDetails  calculateDiscountedBill(@RequestParam String customerType, @RequestParam BigDecimal totalAmount) throws Exception{
		CustomerBillDetails customerBill = new CustomerBillDetails();
		customerBill.setCustomerType(customerType);
		customerBill.setTotalAmount(totalAmount);
		customerBill.setAmountToBePaid(new BigDecimal(0));
		if(totalAmount.doubleValue() <= 0 || totalAmount.doubleValue() > 2147483647){
			throw new Exception("Please enter bill amount between  1 to 2147483647");
		}
		customerBillingService.calculateDiscount(customerBill);
		return customerBill;
		
	}

}
